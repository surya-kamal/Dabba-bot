# ToDo-List-v1

Two route are there:
one is home route i.e. localhost:3000
another one is work route i.e. localhost:3000/work


Before building the project first do npm install,
to install all the node module packages from the dependencies of package.json
